/* Supabase settings.
   Leave both values empty to play in guest mode (saved in this browser only).
   To turn on accounts, paste your project's URL and anon (public) key here.
   Find them in Supabase: Project Settings > API. The anon key is meant to be public;
   your data is protected by the row-level security rules in schema.sql. */
window.BJ_CONFIG = {
  SUPABASE_URL: "",
  SUPABASE_ANON_KEY: "",
  ENABLE_GOOGLE: false   // set to true after you enable the Google provider in Supabase
};
