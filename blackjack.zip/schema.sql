-- Run this once in Supabase: SQL Editor > New query > paste > Run.

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default '',
  username text,
  hometown text not null default '',
  bio text not null default '' check (char_length(bio) <= 280),
  bank numeric not null default 1000 check (bank >= 0),
  created_at timestamptz not null default now(),
  constraint username_format check (username is null or username ~ '^[A-Za-z0-9_]{3,20}$')
);
-- Usernames are unique regardless of upper/lower case.
create unique index if not exists profiles_username_key on public.profiles (lower(username));

create table if not exists public.rounds (
  id bigint generated always as identity primary key,
  user_id uuid not null references auth.users(id) on delete cascade default auth.uid(),
  created_at timestamptz not null default now(),
  strategy text not null default 'Just playing',
  bet_total numeric not null,
  net numeric not null,
  bank_after numeric not null,
  dealer_up text not null,
  dealer_cards jsonb not null default '[]',
  true_count numeric not null default 0,
  start_hand text not null default '',
  hands jsonb not null default '[]',
  mistakes jsonb not null default '[]',
  decisions int not null default 0,
  blackjack boolean not null default false
);
create index if not exists rounds_user_created on public.rounds (user_id, created_at);

-- Each player can only see and change their own data.
alter table public.profiles enable row level security;
alter table public.rounds enable row level security;

drop policy if exists "own profile read" on public.profiles;
drop policy if exists "own profile insert" on public.profiles;
drop policy if exists "own profile update" on public.profiles;
drop policy if exists "own rounds read" on public.rounds;
drop policy if exists "own rounds insert" on public.rounds;

create policy "own profile read" on public.profiles for select using (auth.uid() = id);
create policy "own profile insert" on public.profiles for insert with check (auth.uid() = id);
create policy "own profile update" on public.profiles for update using (auth.uid() = id) with check (auth.uid() = id);
create policy "own rounds read" on public.rounds for select using (auth.uid() = user_id);
create policy "own rounds insert" on public.rounds for insert with check (auth.uid() = user_id);

-- Create a profile row automatically when someone signs up.
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id) values (new.id) on conflict do nothing;
  return new;
end $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();
