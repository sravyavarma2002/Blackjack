/* Storage layer. Uses Supabase when config.js has keys; otherwise saves to this browser (guest mode).
   Both stores expose the same methods so the game doesn't care which one it is using. */
(function (root) {
  "use strict";
  const START_BANK = 1000;

  /* ---------- Guest mode: localStorage ---------- */
  function createLocalStore() {
    const KEY = "bj-local-v2";
    const MAX_ROUNDS = 4000;
    let data = null;
    try { data = JSON.parse(localStorage.getItem(KEY)); } catch (_) {}
    if (!data) data = { bank: START_BANK, profile: { created_at: new Date().toISOString() }, rounds: [] };
    const write = () => { try { localStorage.setItem(KEY, JSON.stringify(data)); } catch (_) {} };

    return {
      mode: "local",
      async getProfile() { return Object.assign({ display_name: "", username: "", hometown: "", bio: "" }, data.profile, { bank: data.bank }); },
      async saveBank(bank) { data.bank = bank; write(); },
      async saveProfile(fields) { Object.assign(data.profile, fields); write(); },
      async addRound(round) {
        data.rounds.push(round);
        if (data.rounds.length > MAX_ROUNDS) data.rounds.shift();
        write();
      },
      async getRounds() { return data.rounds.slice(); }
    };
  }

  /* ---------- Accounts: Supabase ---------- */
  function createCloudStore(cfg) {
    const sb = root.supabase.createClient(cfg.SUPABASE_URL, cfg.SUPABASE_ANON_KEY, {
      auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true }
    });
    let userId = null;
    const origin = () => location.origin + location.pathname;

    async function uid() {
      if (userId) return userId;
      const { data } = await sb.auth.getSession();
      if (!data.session) throw new Error("Not signed in");
      userId = data.session.user.id;
      return userId;
    }
    const check = ({ error }) => { if (error) throw error; };

    return {
      mode: "cloud",
      googleEnabled: !!cfg.ENABLE_GOOGLE,

      onAuth(cb) { sb.auth.onAuthStateChange((event, session) => { userId = session ? session.user.id : null; cb(event, session); }); },
      async getSession() { const { data } = await sb.auth.getSession(); userId = data.session ? data.session.user.id : null; return data.session; },
      async signIn(email, password) { check(await sb.auth.signInWithPassword({ email, password })); },
      async signUp(email, password) {
        const res = await sb.auth.signUp({ email, password, options: { emailRedirectTo: origin() } });
        check(res);
        return { needsConfirmation: !res.data.session };
      },
      async signInWithGoogle() { check(await sb.auth.signInWithOAuth({ provider: "google", options: { redirectTo: origin() } })); },
      async resetPassword(email) { check(await sb.auth.resetPasswordForEmail(email, { redirectTo: origin() })); },
      async updatePassword(password) { check(await sb.auth.updateUser({ password })); },
      async signOut() { userId = null; check(await sb.auth.signOut()); },

      async getProfile() {
        const id = await uid();
        let res = await sb.from("profiles").select("*").eq("id", id).maybeSingle();
        check(res);
        if (!res.data) {
          res = await sb.from("profiles").insert({ id }).select().single();
          check(res);
        }
        return res.data;
      },
      async saveBank(bank) {
        const id = await uid();
        check(await sb.from("profiles").update({ bank }).eq("id", id));
      },
      async saveProfile(fields) {
        const id = await uid();
        const res = await sb.from("profiles").update(fields).eq("id", id);
        if (res.error) {
          if (res.error.code === "23505") { const e = new Error("Username taken"); e.code = "username_taken"; throw e; }
          throw res.error;
        }
      },
      async addRound(round) {
        const id = await uid();
        check(await sb.from("rounds").insert(Object.assign({}, round, { user_id: id })));
      },
      async getRounds() {
        const id = await uid();
        const out = [];
        const PAGE = 1000;                       // Supabase returns at most 1000 rows per request
        for (let from = 0; from < 20000; from += PAGE) {
          const res = await sb.from("rounds").select("*").eq("user_id", id)
            .order("created_at", { ascending: true }).range(from, from + PAGE - 1);
          check(res);
          out.push(...res.data);
          if (res.data.length < PAGE) break;
        }
        return out;
      }
    };
  }

  function createStore(cfg) {
    cfg = cfg || {};
    const hasKeys = !!(cfg.SUPABASE_URL && cfg.SUPABASE_ANON_KEY);
    if (hasKeys && root.supabase) return createCloudStore(cfg);
    const local = createLocalStore();
    if (hasKeys) local.notice = "The Supabase library didn't load (check your connection or ad blocker), so accounts are off and this session is saved in this browser only.";
    return local;
  }

  root.BJ = Object.assign(root.BJ || {}, { createStore, START_BANK });
})(window);
